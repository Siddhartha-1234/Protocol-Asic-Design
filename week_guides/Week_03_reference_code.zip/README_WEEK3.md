# Week 3 reference code: engine v0

Companion to Week_03_Guide.pdf. A Tiny Tapeout IHP template repo with engine v0 added:
one match-action lane, 16 blocks x 4 rules, an SPI-style program loader, 4-deep TX/RX FIFOs,
UART TX/RX programs, 20 cocotb tests, and 3 formal proofs.

Tested on 22 Nov 2026 in a cloud Linux container (Icarus 12.0, Verilator 5.020, Yosys 0.33,
SymbiYosys with z3, cocotb 2.0.1). Not hardened with the IHP PDK yet: that is Week 3, step 15.

    make lint      # Verilator, must be silent
    make test      # 20 cocotb tests
    make formal    # sync, fifo, loader proofs (uses yices; switch [engines] to z3 if needed)
    make synth     # generic Yosys cell count
    python tools/pasm.py programs/uart_tx.pasm --list

Before using: rename tt_um_protoemu (src/project.v, test/tb.v, Makefile, info.yaml),
fill in author in info.yaml, and clone tt-support-tools into tt/ as HOW_TO_RUN.md says.
If you use this code, record it in docs/ai_usage.md: the rules require describing AI use.
