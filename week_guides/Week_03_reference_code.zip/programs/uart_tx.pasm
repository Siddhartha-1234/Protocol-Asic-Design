; UART transmitter, 8N1, LSB first.
; Bytes come from the TX FIFO (the host writes them to register 0x45).
.set CLOCK 50000000          ; core clock in Hz
.set BAUD  115200            ; override with -D BAUD=...
.timer_a CLOCK / BAUD        ; cycles per bit
.counter 8                   ; data bits
.order lsb
.pin TX 0 pushpull init=1    ; idle high
.start IDLE

state IDLE:
    when !TXF_EMPTY do load_tx, TX=0, timer=A, count=load -> BIT   ; start bit
    when ALWAYS     do TX=1                                -> IDLE
state BIT:
    when T0 & C0    do TX=1, timer=A                       -> STOP  ; stop bit
    when T0         do TX=bit, shift_out, count=dec, timer=A -> BIT ; data bit
state STOP:
    when T0                                                -> IDLE
