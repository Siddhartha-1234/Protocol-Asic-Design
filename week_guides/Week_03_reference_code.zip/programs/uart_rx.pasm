; UART receiver, 8N1, LSB first. Received bytes go to the RX FIFO
; (the host reads register 0x46). A bad stop bit sets FLAG.
.set CLOCK 50000000
.set BAUD  115200
.timer_a CLOCK / BAUD        ; one bit
.timer_b CLOCK / BAUD / 2    ; half a bit: move from the start edge to mid-bit
.counter 8
.order lsb
.pin RX 1 input
.in RX
.start IDLE

state IDLE:
    when fall(RX)            do timer=B                         -> START
state START:
    when T0 & RX                                                -> IDLE   ; glitch
    when T0                  do timer=A, count=load             -> DATA
state DATA:
    when C0                                                     -> STOP   ; 8 bits in
    when T0                  do shift_in, count=dec, timer=A    -> DATA
state STOP:
    when T0 & RX             do push_rx                         -> IDLE
    when T0                  do set_flag                        -> IDLE   ; framing error
