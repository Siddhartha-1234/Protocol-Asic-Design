"""Week 3 tests for engine v0.

Instruction-level tests: one behaviour each, tiny programs, exact cycle checks.
Protocol-level tests: UART TX and RX programs against Python reference models.
Every program is sent through the real loader pins, exactly as the RP2350 will.
"""
import os

import cocotb
from cocotb.triggers import ClockCycles, RisingEdge, ReadOnly

from pe_host import (CHIP_ID, CLK_HZ, REG, bit, pad, set_ext, start,
                     uart_receive, uart_send)

PROG_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "programs")


def program(name):
    with open(os.path.join(PROG_DIR, name)) as f:
        return f.read()


async def sample_pin(dut, pin, n):
    """Return the value of uio pin `pin` on each of the next n clock cycles."""
    vals = []
    for _ in range(n):
        await RisingEdge(dut.clk)
        await ReadOnly()
        vals.append(pad(dut, pin))
    await RisingEdge(dut.clk)
    return vals


def run_lengths(vals):
    """[1,1,0,0,0,1] -> [(1,2),(0,3),(1,1)]"""
    out = []
    for v in vals:
        if out and out[-1][0] == v:
            out[-1][1] += 1
        else:
            out.append([v, 1])
    return [tuple(x) for x in out]


# ===================================================== instruction-level tests
@cocotb.test()
async def test_loader_id_and_readback(dut):
    """The loader answers with the chip ID and reads back what it wrote."""
    host = await start(dut)
    assert await host.read(REG["ID"]) == CHIP_ID
    for v in (0x1234, 0xFFFF, 0x0000, 0xA5C3):
        await host.write(REG["TIMER_A"], v)
        got = await host.read(REG["TIMER_A"])
        assert got == v, f"TIMER_A readback {got:#x} != {v:#x}"
    s = await host.status()
    assert s["run"] == 0 and s["rx_valid"] == 0


@cocotb.test()
async def test_reset_state(dut):
    """After reset nothing runs and no pin is driven (flops do not start at 0)."""
    await start(dut)
    assert dut.uio_oe.value.to_unsigned() == 0, "a pin is driven after reset"
    assert bit(dut.uo_out.value.to_unsigned(), 5) == 0, "RUN is set after reset"


TOGGLE = """
.pin P 0 {mode} init=0
state S0:
    when ALWAYS do P=1 -> S1
state S1:
    when ALWAYS do P=0 -> S0
"""


@cocotb.test()
async def test_pin_pushpull(dut):
    """Push-pull pin: the rule's value appears on the pad, toggling every cycle."""
    host = await start(dut)
    await host.load(TOGGLE.format(mode="pushpull"))
    vals = await sample_pin(dut, 0, 20)
    assert all(a != b for a, b in zip(vals, vals[1:])), f"not toggling: {vals}"
    assert bit(dut.uio_oe.value.to_unsigned(), 0) == 1


@cocotb.test()
async def test_pin_opendrain(dut):
    """Open-drain pin: never drives 1; a 1 means 'release' (the pull-up makes it 1)."""
    host = await start(dut)
    await host.load(TOGGLE.format(mode="opendrain"))
    for _ in range(20):
        await RisingEdge(dut.clk)
        await ReadOnly()
        out = bit(dut.uio_out.value.to_unsigned(), 0)
        oe = bit(dut.uio_oe.value.to_unsigned(), 0)
        assert not (oe and out), "open-drain pin drove a 1"
    await RisingEdge(dut.clk)
    # hold the line low from outside: the pad must read 0 even when released
    set_ext(dut, 0, 0)
    vals = await sample_pin(dut, 0, 10)
    assert vals == [0] * 10


TIMER = """
.timer_a {n}
.pin P 0 pushpull init=0
state HI:
    when T0 do P=0, timer=A -> LO
state LO:
    when T0 do P=1, timer=A -> HI
"""


@cocotb.test()
@cocotb.parametrize(n=[1, 2, 5, 37])
async def test_timer_period(dut, n):
    """'.timer_a N' makes the T0 rule fire exactly every N cycles."""
    host = await start(dut)
    await host.load(TIMER.format(n=n))
    runs = run_lengths(await sample_pin(dut, 0, 12 * n + 10))
    inner = [length for _, length in runs[1:-1]]  # drop the partial first and last runs
    assert inner and all(length == n for length in inner), f"n={n}: run lengths {runs}"


PRIORITY = """
.pin P 0 pushpull init=0
state S0:
    when FLAG   do P=1      -> DONE     ; rule 0: wins once FLAG is set
    when ALWAYS do set_flag -> S0       ; rule 1: always true
state DONE:
    when ALWAYS             -> DONE
"""


@cocotb.test()
async def test_rule_priority(dut):
    """When two rules are true, the lower slot fires."""
    host = await start(dut)
    await host.load(PRIORITY)
    await ClockCycles(dut.clk, 10)
    await ReadOnly()
    uo = dut.uo_out.value.to_unsigned()
    assert uo & 0x1F == 1, f"state {uo & 0x1F}, expected DONE (1)"
    assert bit(uo, 6) == 1 and pad(dut, 0) == 1


FOLLOW = """
.pin OUT 0 pushpull init=0
.pin IN 1 input
state S0:
    when rise(IN) do OUT=1 -> S0
    when fall(IN) do OUT=0 -> S0
"""


@cocotb.test()
async def test_edge_guards(dut):
    """rise()/fall() guards fire once per edge; input-to-output latency is 3 cycles."""
    host = await start(dut)
    set_ext(dut, 1, 0)
    await host.load(FOLLOW)
    await ClockCycles(dut.clk, 5)
    for level in (1, 0, 1, 0):
        await RisingEdge(dut.clk)
        set_ext(dut, 1, level)
        lat = 0
        while True:
            await RisingEdge(dut.clk)
            await ReadOnly()
            lat += 1
            if pad(dut, 0) == level:
                break
            assert lat < 10, "output never followed the input"
        await RisingEdge(dut.clk)
        dut._log.info(f"edge to {level}: output followed after {lat} cycles")
        # 2 synchronizer flops + 1 action register (the edge detector is combinational)
        assert lat == 3, f"latency {lat}, expected 3"
        await ClockCycles(dut.clk, 5)


SHIFT = """
.counter 8
.order {order}
.pin P 0 pushpull init=0
state IDLE:
    when !TXF_EMPTY do load_tx, count=load -> B
state B:
    when C0                                 -> END
    when ALWAYS do P=bit, shift_out, count=dec -> B
state END:
    when ALWAYS do P=0 -> END
"""


@cocotb.test()
@cocotb.parametrize(order=["lsb", "msb"])
async def test_shift_out_order(dut, order):
    """Shift-out sends one bit per firing, LSB or MSB first; counter stops it after 8."""
    host = await start(dut)
    await host.load(SHIFT.format(order=order))
    # record (state, pin) every cycle while the byte goes out
    trace = []

    async def recorder():
        for _ in range(600):
            await RisingEdge(dut.clk)
            await ReadOnly()
            trace.append((dut.uo_out.value.to_unsigned() & 0x1F, pad(dut, 0)))

    rec = cocotb.start_soon(recorder())
    await host.send_tx(b"\xA6")
    await rec
    # a rule that fires in cycle i shows its pin value in cycle i+1
    vals = [trace[i + 1][1] for i in range(len(trace) - 1) if trace[i][0] == 1][:8]
    expect = [bit(0xA6, i) for i in range(8)]
    if order == "msb":
        expect = expect[::-1]
    assert vals == expect, f"{order}: got {vals}, expected {expect}"


# ======================================================= protocol-level tests
BAUDS = [115_200, 1_000_000, 3_000_000]


@cocotb.test()
@cocotb.parametrize(baud=BAUDS)
async def test_uart_tx(dut, baud):
    """UART TX program sends bytes that a reference receiver decodes correctly."""
    host = await start(dut)
    await host.load(program("uart_tx.pasm"), CLOCK=CLK_HZ, BAUD=baud)
    cpb = round(CLK_HZ / baud)
    msg = b"\x55\xA3\x00\xFF"
    rx = cocotb.start_soon(uart_receive(dut, 0, cpb, len(msg)))
    await host.send_tx(msg)
    got, periods = await rx
    assert got == msg, f"{baud} baud: got {got.hex()}, sent {msg.hex()}"
    error = abs(cpb - CLK_HZ / baud) / (CLK_HZ / baud)   # rounding error of the baud rate
    dut._log.info(f"{baud} baud: {cpb} cycles/bit, rate error {error * 100:.2f}%, "
                  f"measured start bits {periods}")
    assert all(p == cpb for p in periods), f"bit period {periods} != {cpb}"
    assert error < 0.02


@cocotb.test()
@cocotb.parametrize(baud=BAUDS)
async def test_uart_rx(dut, baud):
    """UART RX program receives bytes from a reference transmitter; host reads them."""
    host = await start(dut)
    await host.load(program("uart_rx.pasm"), CLOCK=CLK_HZ, BAUD=baud)
    msg = b"\x55\xA3\x00\xFF"
    await uart_send(dut, 1, CLK_HZ / baud, msg)        # exact (fractional) rate
    await ClockCycles(dut.clk, 20)
    got = []
    for _ in range(len(msg)):
        s = await host.status()
        assert s["rx_valid"], f"RX FIFO empty after {len(got)} bytes"
        got.append(s["rx"])
    s = await host.status()
    assert not s["rx_valid"], "extra byte in RX FIFO"
    assert s["flag"] == 0, "framing error flagged on good data"
    assert bytes(got) == msg, f"{baud} baud: got {bytes(got).hex()}, sent {msg.hex()}"


@cocotb.test()
async def test_uart_rx_framing_error(dut):
    """A byte whose stop bit is 0 sets FLAG and is not pushed."""
    host = await start(dut)
    await host.load(program("uart_rx.pasm"), CLOCK=CLK_HZ, BAUD=1_000_000)
    await uart_send(dut, 1, CLK_HZ / 1_000_000, b"\x3C", stop_bit=0)
    await ClockCycles(dut.clk, 100)
    s = await host.status()
    assert s["flag"] == 1 and s["rx_valid"] == 0


@cocotb.test()
async def test_reload_after_reset(dut):
    """Deselect loses everything: after a new reset the chip is idle and must be reloaded."""
    host = await start(dut)
    await host.load(program("uart_tx.pasm"), CLOCK=CLK_HZ, BAUD=1_000_000)
    dut.rst_n.value = 0
    await ClockCycles(dut.clk, 5)
    dut.rst_n.value = 1
    await ClockCycles(dut.clk, 5)
    assert dut.uio_oe.value.to_unsigned() == 0
    s = await host.status()
    assert s["run"] == 0
    await host.load(program("uart_tx.pasm"), CLOCK=CLK_HZ, BAUD=1_000_000)
    rx = cocotb.start_soon(uart_receive(dut, 0, 50, 1))
    await host.send_tx(b"\x42")
    got, _ = await rx
    assert got == b"\x42"
