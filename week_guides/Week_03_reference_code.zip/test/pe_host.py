"""Test helpers for the protocol emulator: the host (RP2350) side and protocol models.

Only top-level pins are touched, so every test here also runs at gate level.
"""
import os
import sys

from cocotb.clock import Clock
from cocotb.triggers import ClockCycles, RisingEdge, ReadOnly

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "tools"))
import pasm  # noqa: E402

CLK_NS = 20                 # 50 MHz core clock in simulation
CLK_HZ = 1_000_000_000 // CLK_NS
SCK, MOSI, CS_N = 0, 1, 2   # ui_in bits used by the loader
MISO = 7                    # uo_out bit
REG = pasm.REG
CHIP_ID = 0x5045_0001


def bit(v, i):
    return (v >> i) & 1


async def start(dut):
    """Start the clock, reset the chip, and return a Host bound to it."""
    cocotb_clock = Clock(dut.clk, CLK_NS, unit="ns")
    import cocotb
    cocotb.start_soon(cocotb_clock.start())
    dut.ena.value = 1
    dut.ui_in.value = 1 << CS_N          # CS_N idle high, SCK low
    dut.uio_ext.value = 0xFF             # pull-ups on every uio pin
    dut.rst_n.value = 0
    await ClockCycles(dut.clk, 10)
    dut.rst_n.value = 1
    await ClockCycles(dut.clk, 5)
    return Host(dut)


class Host:
    """Bit-bangs the loader's SPI-style interface, like the RP2350 will."""

    def __init__(self, dut, half=4):
        self.dut = dut
        self.half = half                 # SCK half-period in clk cycles (>= 4)
        self.ui = 1 << CS_N

    async def _set(self, b, v):
        self.ui = (self.ui & ~(1 << b)) | (v << b)
        self.dut.ui_in.value = self.ui

    async def _frame(self, header, data):
        await self._set(CS_N, 0)
        await ClockCycles(self.dut.clk, self.half)
        word = (header << 32) | data
        got = 0
        for i in range(39, -1, -1):
            await self._set(MOSI, bit(word, i))
            await self._set(SCK, 0)
            await ClockCycles(self.dut.clk, self.half)
            got = (got << 1) | bit(self.dut.uo_out.value.to_unsigned(), MISO)  # sample, then rise
            await self._set(SCK, 1)
            await ClockCycles(self.dut.clk, self.half)
        await self._set(SCK, 0)
        await ClockCycles(self.dut.clk, self.half)
        await self._set(CS_N, 1)
        await ClockCycles(self.dut.clk, self.half)
        return got & 0xFFFF_FFFF

    async def write(self, addr, data):
        await self._frame(addr & 0x7F, data & 0xFFFF_FFFF)

    async def read(self, addr):
        return await self._frame(0x80 | (addr & 0x7F), 0)

    async def load(self, source, **defines):
        """Assemble a program (text) and send all its writes. Returns the Program."""
        prog = pasm.assemble(source, defines)
        for addr, data in prog.writes:
            await self.write(addr, data)
        return prog

    async def send_tx(self, data: bytes):
        for b in data:
            await self.write(REG["TXDATA"], b)

    async def status(self):
        s = await self.read(REG["STATUS"])
        return dict(rx=s & 0xFF, rx_valid=bit(s, 8), tx_full=bit(s, 9), flag=bit(s, 10),
                    run=bit(s, 11), state=(s >> 16) & 0x1F)


# ------------------------------------------------------------ pin helpers
def pad(dut, i):
    """Value on uio pin i as the outside world sees it (pad model in tb.v)."""
    return bit(dut.uio_in.value.to_unsigned(), i)


def set_ext(dut, i, v):
    e = dut.uio_ext.value.to_unsigned()
    dut.uio_ext.value = (e & ~(1 << i)) | (v << i)


# ------------------------------------------------------------ UART models
async def uart_receive(dut, pin, cycles_per_bit, nbytes, timeout_bits=200):
    """Reference UART receiver: watch a pin, return (bytes, measured bit period)."""
    out = []
    periods = []
    for _ in range(nbytes):
        waited = 0
        while pad(dut, pin) == 1:          # wait for the start bit edge
            await RisingEdge(dut.clk)
            await ReadOnly()
            waited += 1
            assert waited < timeout_bits * cycles_per_bit, "UART: no start bit"
        # walk to the centre of data bit 0, noting when the start bit ends
        # (that gives the bit period whenever data bit 0 is 1)
        centre0 = int(1.5 * cycles_per_bit)
        t_start = None
        for pos in range(1, centre0 + 1):
            await RisingEdge(dut.clk)
            await ReadOnly()
            if t_start is None and pad(dut, pin) == 1:
                t_start = pos
        if t_start is not None:
            periods.append(t_start)
        val = 0
        pos = centre0
        for b in range(9):                  # 8 data bits, then the stop bit
            centre = int((1.5 + b) * cycles_per_bit)
            if centre > pos:
                await ClockCycles(dut.clk, centre - pos)
                await ReadOnly()
            pos = centre
            v = pad(dut, pin)
            if b < 8:
                val |= v << b
            else:
                assert v == 1, "UART: stop bit is 0 (framing error)"
        out.append(val)
        await RisingEdge(dut.clk)
    return bytes(out), periods


async def uart_send(dut, pin, cycles_per_bit, data: bytes, stop_bit=1):
    """Reference UART transmitter: drive a pin from outside the chip.

    cycles_per_bit may be fractional (for example 50 MHz / 3 Mbaud = 16.67):
    bit edges are placed at round(k * cycles_per_bit), like a real, slightly
    mismatched remote device, so the chip's rounding error is really tested.
    """
    t = 0.0
    now = 0
    for byte in data:
        frame = [0] + [bit(byte, i) for i in range(8)] + [stop_bit] + [1]  # + 1 idle bit
        for v in frame:
            set_ext(dut, pin, v)
            t += cycles_per_bit
            await ClockCycles(dut.clk, round(t) - now)
            now = round(t)
