/*
 * pe_fifo: small synchronous FIFO built from flip-flops.
 *   DEPTH = 2**AW entries of W bits.
 *   push when full is ignored (data dropped); pop when empty is ignored.
 *   dout always shows the oldest entry (valid only when !empty).
 * Pointers carry one extra bit so that full and empty can be told apart.
 */
`default_nettype none

module pe_fifo #(
    parameter W  = 8,
    parameter AW = 2
) (
    input  wire         clk,
    input  wire         rst_n,
    input  wire         push,
    input  wire [W-1:0] din,
    input  wire         pop,
    output wire [W-1:0] dout,
    output wire         empty,
    output wire         full,
    output wire [AW:0]  count
);
  localparam DEPTH = 1 << AW;

  reg [W-1:0] mem[0:DEPTH-1];  // no reset: contents are don't-care until written
  reg [AW:0]  wp, rp;

  assign count = wp - rp;
  assign empty = (wp == rp);
  assign full  = (wp[AW] != rp[AW]) && (wp[AW-1:0] == rp[AW-1:0]);

  wire do_push = push && !full;
  wire do_pop  = pop && !empty;

  always @(posedge clk) begin
    if (!rst_n) begin
      wp <= {(AW + 1) {1'b0}};
      rp <= {(AW + 1) {1'b0}};
    end else begin
      if (do_push) wp <= wp + 1'b1;
      if (do_pop) rp <= rp + 1'b1;
    end
  end

  always @(posedge clk) if (do_push) mem[wp[AW-1:0]] <= din;

  assign dout = mem[rp[AW-1:0]];

`ifdef FORMAL
  reg f_past_valid = 1'b0;
  always @(posedge clk) f_past_valid <= 1'b1;
  always @(*) if (!f_past_valid) assume (!rst_n);

  // 1. Occupancy never exceeds the depth
  always @(*) if (f_past_valid) assert (count <= DEPTH);

  // 2. Flags agree with the count
  always @(*) if (f_past_valid) assert (empty == (count == 0));
  always @(*) if (f_past_valid) assert (full == (count == DEPTH));

  // 3. Reset really empties the FIFO
  always @(posedge clk) if (f_past_valid && !$past(rst_n)) assert (empty);

  // 4. Count moves by exactly the push/pop that were accepted
  always @(posedge clk)
    if (f_past_valid && $past(rst_n))
      assert (count == $past(count) + ($past(do_push) ? 1 : 0) - ($past(do_pop) ? 1 : 0));

  // 5. Data integrity: pick ANY value and ANY slot the solver likes.
  //    If that value was written into that slot and the slot has not been
  //    overwritten, then when it reaches the head it must come out unchanged.
  (* anyconst *) reg [AW-1:0] f_slot;
  (* anyconst *) reg [W-1:0]  f_data;
  reg f_tracking = 1'b0;
  always @(posedge clk) begin
    if (!rst_n) f_tracking <= 1'b0;
    else if (do_push && wp[AW-1:0] == f_slot && din == f_data) f_tracking <= 1'b1;
    else if (do_pop && rp[AW-1:0] == f_slot) f_tracking <= 1'b0;
  end
  // while tracked, the slot must still hold the value and be inside the live window
  wire [AW:0] f_dist = {1'b0, f_slot} - rp[AW-1:0];  // distance of slot from head
  always @(*)
    if (f_past_valid && rst_n && f_tracking) begin
      assert (mem[f_slot] == f_data);
      assert (!empty);
      assert (f_dist[AW-1:0] < count);
    end
  always @(*)
    if (f_past_valid && rst_n && f_tracking && rp[AW-1:0] == f_slot) assert (dout == f_data);

  // Covers: show the interesting states are reachable (not a vacuous proof)
  always @(*) cover (f_past_valid && full);
  reg f_was_full = 1'b0;
  always @(posedge clk) if (rst_n && full) f_was_full <= 1'b1;
  always @(*) cover (f_was_full && empty && rst_n);
`endif

endmodule
