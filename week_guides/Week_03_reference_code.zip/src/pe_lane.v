/*
 * pe_lane: one match-action lane (engine v0).
 *
 * Every clock the lane reads the 4 rules of its current state (block),
 * evaluates all 4 guards in parallel, and the lowest-numbered rule whose
 * guard is true FIRES: its actions happen on this clock edge and the lane
 * moves to the rule's next state. If no rule is true, nothing changes
 * except the timer, which keeps counting down to zero.
 *
 * Rule word (32 bits):
 *   [31:27] guard A source   [26] guard A negate
 *   [25:21] guard B source   [20] guard B negate     fires when A AND B
 *   [19:18] pin op           00 none, 01 pin=0, 10 pin=1, 11 pin=shift-out bit
 *   [17:16] pin select       logical pin 0..3
 *   [15:14] reserved (0)
 *   [13:12] shift op         00 none, 01 shift in from IN_PIN, 10 shift out, 11 load from TX FIFO
 *   [11:10] timer op         00 none, 01 load TIMER_A, 10 load TIMER_B, 11 reserved
 *   [9:8]   counter op       00 none, 01 load CNT_INIT, 10 decrement, 11 reserved
 *   [7:5]   fifo/flag op     000 none, 001 push shift reg to RX FIFO, 010 set flag, 011 clear flag
 *   [4:0]   next state
 *
 * Guard sources: 0 ALWAYS, 1 T0 (timer==0), 2 C0 (counter==0), 3 FLAG,
 *   4 TXF_EMPTY, 5 RXF_FULL, 6 SHBIT (next bit to send), 7 LASTBIT,
 *   8..11 LVL pin0..3, 12..15 RISE pin0..3, 16..19 FALL pin0..3, others = 0.
 */
`default_nettype none

module pe_lane #(
    parameter SW = 8  // shift register width (v0: one byte)
) (
    input  wire         clk,
    input  wire         rst_n,
    // control and configuration (from the loader's registers)
    input  wire         run,
    input  wire [4:0]   start_state,
    input  wire [15:0]  timer_a,
    input  wire [15:0]  timer_b,
    input  wire [5:0]   cnt_init,
    input  wire         msb_first,
    input  wire [1:0]   in_sel,
    input  wire [3:0]   pin_init,
    // the 4 rules of the current state, rule 0 in bits [31:0]
    input  wire [127:0] rules,
    output reg  [4:0]   state,
    // pins (already synchronized and polarity-corrected)
    input  wire [3:0]   pin_lvl,
    input  wire [3:0]   pin_rise,
    input  wire [3:0]   pin_fall,
    output reg  [3:0]   pin_val,
    // FIFOs
    input  wire         txf_empty,
    input  wire [SW-1:0] txf_data,
    output wire         txf_pop,
    input  wire         rxf_full,
    output wire         rxf_push,
    output wire [SW-1:0] rxf_data,
    output reg          flag
);
  reg [15:0]   tmr;
  reg [5:0]    cnt;
  reg [SW-1:0] sh;
  reg          lastbit;

  wire t0    = (tmr == 16'd0);
  wire c0    = (cnt == 6'd0);
  wire shbit = msb_first ? sh[SW-1] : sh[0];

  // all guard sources as one vector, indexed by the 5-bit source field
  wire [31:0] src = {12'd0, pin_fall, pin_rise, pin_lvl,
                     lastbit, shbit, rxf_full, txf_empty, flag, c0, t0, 1'b1};

  // evaluate the 4 guards in parallel
  wire [3:0] ok;
  genvar k;
  generate
    for (k = 0; k < 4; k = k + 1) begin : g_guard
      wire [11:0] gd = rules[32*k+20+:12];  // the guard fields of rule k
      assign ok[k] = (src[gd[11:7]] ^ gd[6]) & (src[gd[5:1]] ^ gd[0]);
    end
  endgenerate

  // fixed priority: rule 0 beats rule 1 beats rule 2 beats rule 3
  wire [1:0] sel = ok[0] ? 2'd0 : ok[1] ? 2'd1 : ok[2] ? 2'd2 : 2'd3;
  wire       fire = run & (|ok);
  wire [31:0] r   = rules[32*sel+:32];

  wire [1:0] pin_op = r[19:18];
  wire [1:0] pin_s  = r[17:16];
  wire [1:0] sh_op  = r[13:12];
  wire [1:0] tm_op  = r[11:10];
  wire [1:0] cn_op  = r[9:8];
  wire [2:0] fx_op  = r[7:5];
  wire [4:0] nxt    = r[4:0];

  wire in_bit = pin_lvl[in_sel];
  wire _unused = &{r[31:20], r[15:14], 1'b0};  // guards were used above

  assign txf_pop  = fire && (sh_op == 2'b11) && !txf_empty;
  assign rxf_push = fire && (fx_op == 3'b001);
  assign rxf_data = sh;

  always @(posedge clk) begin
    if (!rst_n || !run) begin
      state   <= start_state;
      tmr     <= 16'd0;
      cnt     <= 6'd0;
      sh      <= {SW{1'b0}};
      lastbit <= 1'b0;
      flag    <= 1'b0;
      pin_val <= pin_init;
    end else begin
      // timer: a rule may reload it, otherwise it counts down and stops at 0
      if (fire && tm_op == 2'b01) tmr <= timer_a;
      else if (fire && tm_op == 2'b10) tmr <= timer_b;
      else if (!t0) tmr <= tmr - 16'd1;

      if (fire) begin
        state <= nxt;

        case (pin_op)
          2'b01: pin_val[pin_s] <= 1'b0;
          2'b10: pin_val[pin_s] <= 1'b1;
          2'b11: begin
            pin_val[pin_s] <= shbit;
            lastbit        <= shbit;
          end
          default: ;
        endcase

        case (sh_op)
          2'b01: sh <= msb_first ? {sh[SW-2:0], in_bit} : {in_bit, sh[SW-1:1]};
          2'b10: sh <= msb_first ? {sh[SW-2:0], 1'b0} : {1'b0, sh[SW-1:1]};
          2'b11: if (!txf_empty) sh <= txf_data;
          default: ;
        endcase

        case (cn_op)
          2'b01: cnt <= cnt_init;
          2'b10: if (!c0) cnt <= cnt - 6'd1;
          default: ;
        endcase

        case (fx_op)
          3'b010: flag <= 1'b1;
          3'b011: flag <= 1'b0;
          default: ;
        endcase
      end
    end
  end

endmodule
