/*
 * Protocol emulator, engine v0 (Week 3): one match-action lane,
 * 16 blocks x 4 rules, SPI-style program loader, 4-deep TX/RX byte FIFOs.
 *
 * Pin map (v0 draft):
 *   ui_in[0]  LD_SCK   host loader clock          (input)
 *   ui_in[1]  LD_MOSI  host loader data in        (input)
 *   ui_in[2]  LD_CS_N  host loader chip select    (input, active low)
 *   ui_in[7:3]         unused in v0
 *   uo_out[4:0]        lane state (debug)
 *   uo_out[5]          RUN
 *   uo_out[6]          FLAG
 *   uo_out[7] LD_MISO  host loader data out
 *   uio[3:0]           lane logical pins 0..3 (input / push-pull / open-drain)
 *   uio[7:4]           unused in v0 (inputs)
 *
 * Register map (loader address, 32-bit data):
 *   0x00-0x3F  rule store, address = block*4 + slot          (write only)
 *   0x40 CTRL      [0] RUN, [8:4] START_STATE
 *   0x41 TIMER_A   [15:0]
 *   0x42 TIMER_B   [15:0]
 *   0x43 LANE_CFG  [5:0] CNT_INIT, [6] MSB_FIRST, [9:8] IN_SEL
 *   0x44 PIN_CFG   per logical pin k: [4k+1:4k] mode (00 input, 01 push-pull,
 *                  10 open-drain), [4k+2] invert, [4k+3] initial value
 *   0x45 TXDATA    write [7:0]: push a byte into the TX FIFO
 *   0x46 STATUS    read: [7:0] RX byte, [8] RX valid, [9] TX full, [10] FLAG,
 *                  [11] RUN, [20:16] state. A full read pops the RX byte.
 *   0x47 ID        read: 0x5045_0001
 */
`default_nettype none

module tt_um_protoemu (
    input  wire [7:0] ui_in,
    output wire [7:0] uo_out,
    input  wire [7:0] uio_in,
    output wire [7:0] uio_out,
    output wire [7:0] uio_oe,
    input  wire       ena,
    input  wire       clk,
    input  wire       rst_n
);
  localparam [31:0] CHIP_ID = 32'h5045_0001;

  // ---------------------------------------------------------------- loader
  wire [2:0] ld_q, ld_rise, ld_fall;
  pe_sync #(.W(3)) u_ld_sync (
      .clk(clk), .rst_n(rst_n), .d_async(ui_in[2:0]),
      .q(ld_q), .rise(ld_rise), .fall(ld_fall)
  );

  wire        wr_en, rd_done, rd_load, miso;
  wire [6:0]  wr_addr, rd_addr;
  wire [31:0] wr_data;
  reg  [31:0] rd_data;

  pe_loader u_loader (
      .clk(clk), .rst_n(rst_n),
      .cs_n(ld_q[2]), .mosi(ld_q[1]), .sck_rise(ld_rise[0]), .sck_fall(ld_fall[0]),
      .miso(miso),
      .wr_en(wr_en), .wr_addr(wr_addr), .wr_data(wr_data),
      .rd_addr(rd_addr), .rd_data(rd_data), .rd_load(rd_load), .rd_done(rd_done)
  );

  // ------------------------------------------------------- config registers
  reg        run;
  reg [4:0]  start_state;
  reg [15:0] timer_a, timer_b;
  reg [5:0]  cnt_init;
  reg        msb_first;
  reg [1:0]  in_sel;
  reg [15:0] pin_cfg;

  always @(posedge clk) begin
    if (!rst_n) begin
      run         <= 1'b0;
      start_state <= 5'd0;
      timer_a     <= 16'd0;
      timer_b     <= 16'd0;
      cnt_init    <= 6'd0;
      msb_first   <= 1'b0;
      in_sel      <= 2'd0;
      pin_cfg     <= 16'd0;  // all pins inputs after reset: nothing is driven
    end else if (wr_en) begin
      case (wr_addr)
        7'h40: begin
          run         <= wr_data[0];
          start_state <= wr_data[8:4];
        end
        7'h41: timer_a <= wr_data[15:0];
        7'h42: timer_b <= wr_data[15:0];
        7'h43: begin
          cnt_init  <= wr_data[5:0];
          msb_first <= wr_data[6];
          in_sel    <= wr_data[9:8];
        end
        7'h44: pin_cfg <= wr_data[15:0];
        default: ;
      endcase
    end
  end

  // ------------------------------------------------------------ rule store
  // 64 x 32-bit words in flip-flops, NOT reset (2048 flops: reset costs area).
  // They hold garbage until loaded, which is why RUN resets to 0.
  reg  [31:0] rule_mem[0:63];
  wire [4:0]  state;

  always @(posedge clk) if (wr_en && !wr_addr[6]) rule_mem[wr_addr[5:0]] <= wr_data;

  wire [3:0]   blk = state[3:0];  // v0 has 16 blocks; state[4] is ignored
  wire [127:0] rules = {rule_mem[{blk, 2'd3}], rule_mem[{blk, 2'd2}],
                        rule_mem[{blk, 2'd1}], rule_mem[{blk, 2'd0}]};

  // ------------------------------------------------------------------ FIFOs
  wire [7:0] txf_dout, rxf_dout, rxf_din;
  wire       txf_empty, txf_full, txf_pop;
  wire       rxf_empty, rxf_full, rxf_push;
  wire [2:0] txf_count, rxf_count;

  pe_fifo #(.W(8), .AW(2)) u_txf (
      .clk(clk), .rst_n(rst_n),
      .push(wr_en && wr_addr == 7'h45), .din(wr_data[7:0]),
      .pop(txf_pop), .dout(txf_dout),
      .empty(txf_empty), .full(txf_full), .count(txf_count)
  );

  // pop the RX byte only if the host actually saw a valid byte in this read
  reg rx_pop_ok;
  always @(posedge clk)
    if (!rst_n) rx_pop_ok <= 1'b0;
    else if (rd_load) rx_pop_ok <= !rxf_empty && rd_addr == 7'h46;

  pe_fifo #(.W(8), .AW(2)) u_rxf (
      .clk(clk), .rst_n(rst_n),
      .push(rxf_push), .din(rxf_din),
      .pop(rd_done && rx_pop_ok), .dout(rxf_dout),
      .empty(rxf_empty), .full(rxf_full), .count(rxf_count)
  );

  // ------------------------------------------------------------------- pins
  wire [3:0] pin_inv = {pin_cfg[14], pin_cfg[10], pin_cfg[6], pin_cfg[2]};
  wire [3:0] pin_ini = {pin_cfg[15], pin_cfg[11], pin_cfg[7], pin_cfg[3]};

  wire [3:0] p_q, p_rise, p_fall;
  pe_sync #(.W(4)) u_pin_sync (
      .clk(clk), .rst_n(rst_n), .d_async(uio_in[3:0]),
      .q(p_q), .rise(p_rise), .fall(p_fall)
  );
  // polarity correction after the synchronizer: an inverted pin swaps rise/fall
  wire [3:0] pin_lvl  = p_q ^ pin_inv;
  wire [3:0] pin_rise = (p_rise & ~pin_inv) | (p_fall & pin_inv);
  wire [3:0] pin_fall = (p_fall & ~pin_inv) | (p_rise & pin_inv);

  wire [3:0] pin_val;
  wire       flag;

  pe_lane #(.SW(8)) u_lane (
      .clk(clk), .rst_n(rst_n),
      .run(run), .start_state(start_state),
      .timer_a(timer_a), .timer_b(timer_b),
      .cnt_init(cnt_init), .msb_first(msb_first), .in_sel(in_sel),
      .pin_init(pin_ini),
      .rules(rules), .state(state),
      .pin_lvl(pin_lvl), .pin_rise(pin_rise), .pin_fall(pin_fall),
      .pin_val(pin_val),
      .txf_empty(txf_empty), .txf_data(txf_dout), .txf_pop(txf_pop),
      .rxf_full(rxf_full), .rxf_push(rxf_push), .rxf_data(rxf_din),
      .flag(flag)
  );

  // drive modes: 00 input, 01 push-pull, 10 open-drain (drive 0 / release), 11 input
  reg [3:0] p_out, p_oe;
  integer i;
  always @(*) begin
    for (i = 0; i < 4; i = i + 1) begin
      case (pin_cfg[4*i+:2])
        2'b01:   begin p_out[i] = pin_val[i] ^ pin_inv[i]; p_oe[i] = 1'b1; end
        2'b10:   begin p_out[i] = 1'b0; p_oe[i] = ~(pin_val[i] ^ pin_inv[i]); end
        default: begin p_out[i] = 1'b0; p_oe[i] = 1'b0; end
      endcase
    end
  end

  assign uio_out = {4'b0000, p_out};
  assign uio_oe  = {4'b0000, p_oe};
  assign uo_out  = {miso, flag, run, state};

  // ------------------------------------------------------------- read mux
  always @(*) begin
    case (rd_addr)
      7'h40:   rd_data = {23'd0, start_state, 3'd0, run};
      7'h41:   rd_data = {16'd0, timer_a};
      7'h42:   rd_data = {16'd0, timer_b};
      7'h43:   rd_data = {22'd0, in_sel, 1'b0, msb_first, cnt_init};
      7'h44:   rd_data = {16'd0, pin_cfg};
      // mask the RX byte when the FIFO is empty: its memory is never reset,
      // so an empty FIFO's head is X in simulation (garbage on silicon)
      7'h46:   rd_data = {11'd0, state, 4'd0, run, flag, txf_full, !rxf_empty,
                          rxf_empty ? 8'h00 : rxf_dout};
      7'h47:   rd_data = CHIP_ID;
      default: rd_data = 32'd0;
    endcase
  end

  wire _unused = &{ena, ui_in[7:3], uio_in[7:4], ld_q[0], ld_rise[2:1], ld_fall[2:1],
                   txf_count, rxf_count, 1'b0};

endmodule
