/*
 * pe_sync: 2-flop synchronizer plus edge detector, W bits wide.
 * Every pin that comes from outside the chip passes through this first.
 *   q    : synchronized level (2 clock cycles of latency)
 *   rise : 1-cycle pulse when q goes 0 -> 1
 *   fall : 1-cycle pulse when q goes 1 -> 0
 * Each bit is synchronized on its own. That is fine for independent pins,
 * but NOT for a multi-bit value that must be read as one word.
 */
`default_nettype none

module pe_sync #(
    parameter W = 1
) (
    input  wire         clk,
    input  wire         rst_n,
    input  wire [W-1:0] d_async,
    output wire [W-1:0] q,
    output wire [W-1:0] rise,
    output wire [W-1:0] fall
);
  reg [W-1:0] s1, s2, s3;

  always @(posedge clk) begin
    if (!rst_n) begin
      s1 <= {W{1'b0}};
      s2 <= {W{1'b0}};
      s3 <= {W{1'b0}};
    end else begin
      s1 <= d_async;  // may go metastable; never used directly
      s2 <= s1;       // safe to use
      s3 <= s2;       // previous value, for edge detection
    end
  end

  assign q    = s2;
  assign rise = s2 & ~s3;
  assign fall = ~s2 & s3;

`ifdef FORMAL
  // ---------------- formal properties ----------------
  reg f_past_valid = 1'b0;
  always @(posedge clk) f_past_valid <= 1'b1;

  // Start the proof in reset
  always @(*) if (!f_past_valid) assume (!rst_n);

  // A pin can never rise and fall in the same cycle
  always @(*) assert ((rise & fall) == {W{1'b0}});

  // A rise pulse means the level is now 1; a fall pulse means it is now 0
  always @(*) assert ((rise & ~q) == {W{1'b0}});
  always @(*) assert ((fall & q) == {W{1'b0}});

  // The synchronized level is the input from exactly two clocks ago
  always @(posedge clk)
    if (f_past_valid && $past(rst_n) && $past(rst_n, 2) && $past(f_past_valid, 2))
      assert (q == $past(d_async, 2));

  // Liveness-style sanity: both edges can actually happen
  always @(*) cover (rise[0]);
  always @(*) cover (fall[0]);
`endif

endmodule
