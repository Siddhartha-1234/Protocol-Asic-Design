/*
 * pe_loader: host interface, an SPI target (mode 0) that the RP2350 drives.
 *
 * Frame (CS_N low, MSB first, MOSI sampled on SCK rising edge):
 *   byte 0      : {RW, ADDR[6:0]}   RW = 0 write, 1 read
 *   bytes 1..4  : DATA[31:0]        write: data from host
 *                                   read : data to host on MISO
 * Exactly 40 SCK cycles per frame. Raising CS_N aborts a frame.
 *
 * All inputs here are ALREADY synchronized (see pe_sync in the top level),
 * so SCK must be slow compared with clk: keep each SCK half-period at least
 * 4 clk cycles (SCK <= clk/8 is a safe rule).
 *
 * Read timing: the read word is captured one clk after the 8th SCK rise.
 * MISO shows bit 31 from then on and moves to the next bit after each SCK
 * fall, so the host samples it on the following SCK rise (mode 0).
 */
`default_nettype none

module pe_loader (
    input  wire        clk,
    input  wire        rst_n,
    // synchronized host pins
    input  wire        cs_n,
    input  wire        mosi,
    input  wire        sck_rise,
    input  wire        sck_fall,
    output wire        miso,
    // write port (1-cycle pulse)
    output reg         wr_en,
    output reg  [6:0]  wr_addr,
    output reg  [31:0] wr_data,
    // read port
    output reg  [6:0]  rd_addr,    // valid from the cycle after the header
    input  wire [31:0] rd_data,    // combinational read data for rd_addr
    output wire        rd_load,    // 1-cycle pulse: rd_data is being captured now
    output reg         rd_done     // 1-cycle pulse at the end of a full read frame
);
  reg [37:0] sh;         // last 38 bits received (the RW bit is kept in is_read)
  reg [5:0]  bitcnt;     // SCK rises seen in this frame, saturates at 63
  reg [31:0] out;        // read shift register
  reg        load_pend;  // load 'out' on the next cycle
  reg        is_read;

  wire active = !cs_n;

  always @(posedge clk) begin
    if (!rst_n) begin
      sh        <= 38'd0;
      bitcnt    <= 6'd0;
      out       <= 32'd0;
      load_pend <= 1'b0;
      is_read   <= 1'b0;
      wr_en     <= 1'b0;
      wr_addr   <= 7'd0;
      wr_data   <= 32'd0;
      rd_addr   <= 7'd0;
      rd_done   <= 1'b0;
    end else begin
      wr_en     <= 1'b0;  // default: pulses last one cycle
      rd_done   <= 1'b0;
      load_pend <= 1'b0;

      if (!active) begin
        bitcnt  <= 6'd0;
        is_read <= 1'b0;
      end else begin
        if (sck_rise) begin
          sh <= {sh[36:0], mosi};
          if (bitcnt != 6'd63) bitcnt <= bitcnt + 6'd1;

          // header complete on the 8th rise
          if (bitcnt == 6'd7) begin
            is_read   <= sh[6];  // first bit of the frame
            rd_addr   <= {sh[5:0], mosi};
            load_pend <= sh[6];
          end

          // frame complete on the 40th rise
          if (bitcnt == 6'd39) begin
            if (!is_read) begin
              wr_en   <= 1'b1;
              wr_addr <= sh[37:31];
              wr_data <= {sh[30:0], mosi};
            end else begin
              rd_done <= 1'b1;
            end
          end
        end

        // shift the read word out after each falling edge (once bit 31 was sampled)
        if (sck_fall && is_read && bitcnt >= 6'd9 && bitcnt <= 6'd39) out <= {out[30:0], 1'b0};
      end

      if (load_pend) out <= rd_data;
    end
  end

  assign miso    = active && is_read && out[31];
  assign rd_load = load_pend;

`ifdef FORMAL
  reg f_past_valid = 1'b0;
  always @(posedge clk) f_past_valid <= 1'b1;
  always @(*) if (!f_past_valid) assume (!rst_n);

  // Environment: the synchronizer never reports a rise and a fall together
  always @(*) assume (!(sck_rise && sck_fall));

  // Ghost model of the host: the last 40 bits sent, and how many bits
  // have been sent since CS went low
  reg [39:0] f_word;
  reg [5:0]  f_bits;
  always @(posedge clk) begin
    if (!rst_n) f_word <= 40'd0;
    else if (active && sck_rise) f_word <= {f_word[38:0], mosi};

    if (!rst_n || !active) f_bits <= 6'd0;
    else if (sck_rise && f_bits != 6'd63) f_bits <= f_bits + 6'd1;
  end

  // 1. Pulses are single-cycle and never overlap
  always @(*) if (f_past_valid) assert (!(wr_en && rd_done));
  always @(posedge clk) if (f_past_valid && $past(wr_en)) assert (!wr_en);

  // 2. THE property: a write happens only after exactly 40 bits of a write
  //    frame, and it writes exactly the address and data that were sent
  always @(posedge clk)
    if (f_past_valid && rst_n && wr_en) begin
      assert (f_bits == 6'd40);
      assert (f_word[39] == 1'b0);
      assert (wr_addr == f_word[38:32]);
      assert (wr_data == f_word[31:0]);
    end

  // 3. Any frame that gets 40 bits as a write produces a write
  always @(posedge clk)
    if (f_past_valid && $past(rst_n) && $past(active) && $past(sck_rise)
        && $past(f_bits) == 6'd39 && !$past(is_read))
      assert (wr_en);

  // Helper invariants (needed for induction, see the guide)
  always @(*) if (f_past_valid && rst_n) begin
    assert (bitcnt == f_bits);
    assert (sh == f_word[37:0]);
    if (bitcnt >= 6'd8 && bitcnt <= 6'd40) assert (is_read == f_word[bitcnt - 6'd1]);
    if (bitcnt < 6'd8) assert (!is_read);
  end

  // Covers: a write and a read can both complete
  always @(*) cover (wr_en && wr_addr == 7'h45 && wr_data == 32'h0000_00A5);
  always @(*) cover (rd_done);
`endif

endmodule
