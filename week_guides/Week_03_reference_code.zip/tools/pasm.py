#!/usr/bin/env python3
"""pasm: assembler for the protocol-emulator match-action engine (v0 rule format).

Usage:
    python tools/pasm.py programs/uart_tx.pasm -D BAUD=115200 -o build/uart_tx.hex
    python tools/pasm.py programs/uart_tx.pasm --list        # human-readable listing

Output (.hex): one loader write per line, "AA DDDDDDDD" (address, data, hex).
The cocotb tests and, later, the RP2350 firmware send these lines in order.
"""
import argparse
import ast
import operator
import re
import sys

# ----------------------------------------------------------------- encoding
GUARD_SRC = {"ALWAYS": 0, "T0": 1, "C0": 2, "FLAG": 3, "TXF_EMPTY": 4,
             "RXF_FULL": 5, "SHBIT": 6, "LASTBIT": 7}
PIN_LVL, PIN_RISE, PIN_FALL = 8, 12, 16
PIN_MODES = {"input": 0, "pushpull": 1, "opendrain": 2}
REG = {"CTRL": 0x40, "TIMER_A": 0x41, "TIMER_B": 0x42, "LANE_CFG": 0x43,
       "PIN_CFG": 0x44, "TXDATA": 0x45, "STATUS": 0x46, "ID": 0x47}
NUM_BLOCKS = 16           # v0 rule store: 16 blocks x 4 rules
RULES_PER_BLOCK = 4
NEVER = (0 << 27) | (1 << 26)  # guard A = NOT ALWAYS -> can never fire


class AsmError(Exception):
    pass


def encode_rule(ga, gb, pin_op=0, pin_sel=0, sh_op=0, tm_op=0, cn_op=0, fx_op=0, nxt=0):
    """Pack one rule. ga and gb are (source, negate) pairs."""
    w = (ga[0] << 27) | (ga[1] << 26) | (gb[0] << 21) | (gb[1] << 20)
    w |= (pin_op << 18) | (pin_sel << 16) | (sh_op << 12) | (tm_op << 10)
    w |= (cn_op << 8) | (fx_op << 5) | nxt
    return w


# ------------------------------------------------- safe arithmetic in values
_OPS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
        ast.Div: operator.truediv, ast.FloorDiv: operator.floordiv,
        ast.USub: operator.neg}


def _eval(expr, names):
    def ev(n):
        if isinstance(n, ast.Expression):
            return ev(n.body)
        if isinstance(n, ast.Constant) and isinstance(n.value, (int, float)):
            return n.value
        if isinstance(n, ast.Name):
            if n.id not in names:
                raise AsmError(f"unknown name '{n.id}' (define it with .set or -D)")
            return names[n.id]
        if isinstance(n, ast.BinOp) and type(n.op) in _OPS:
            return _OPS[type(n.op)](ev(n.left), ev(n.right))
        if isinstance(n, ast.UnaryOp) and type(n.op) in _OPS:
            return _OPS[type(n.op)](ev(n.operand))
        raise AsmError(f"unsupported expression: {expr}")
    return ev(ast.parse(expr, mode="eval"))


# ------------------------------------------------------------------ program
class Program:
    def __init__(self):
        self.names = {}
        self.timer = {"A": None, "B": None}
        self.cnt_init = 0
        self.msb_first = 0
        self.in_pin = None
        self.pins = {}          # name -> (index, mode, invert, init)
        self.start = None
        self.states = []        # [(name, [rule_text, ...], line_no)]
        self.writes = []        # [(addr, data)]
        self.listing = []

    def pin_index(self, name, line):
        if name not in self.pins:
            raise AsmError(f"line {line}: unknown pin '{name}' (declare it with .pin)")
        return self.pins[name][0]


def parse(text, defines=None):
    p = Program()
    p.names.update(defines or {})
    cur = None
    for ln, raw in enumerate(text.splitlines(), 1):
        line = re.split(r"[;#]", raw, maxsplit=1)[0].strip()
        if not line:
            continue
        if line.startswith("."):
            parts = line.split()
            d, args = parts[0].lower(), parts[1:]
            if d == ".set":                      # .set NAME expr   (-D wins)
                if args[0] not in (defines or {}):
                    p.names[args[0]] = _eval(" ".join(args[1:]), p.names)
            elif d in (".timer_a", ".timer_b"):  # cycles per period
                cycles = round(_eval(" ".join(args), p.names))
                if not 1 <= cycles <= 65536:
                    raise AsmError(f"line {ln}: timer period {cycles} cycles out of range 1..65536")
                p.timer[d[-1].upper()] = cycles
            elif d == ".counter":
                v = int(_eval(" ".join(args), p.names))
                if not 0 <= v <= 63:
                    raise AsmError(f"line {ln}: counter init {v} out of range 0..63")
                p.cnt_init = v
            elif d == ".order":
                if args[0] not in ("lsb", "msb"):
                    raise AsmError(f"line {ln}: .order must be lsb or msb")
                p.msb_first = 1 if args[0] == "msb" else 0
            elif d == ".pin":                    # .pin NAME index mode [init=0|1] [invert]
                name, idx, mode = args[0], int(args[1]), args[2]
                if mode not in PIN_MODES or not 0 <= idx <= 3:
                    raise AsmError(f"line {ln}: bad .pin (index 0..3, mode {list(PIN_MODES)})")
                init = 0
                inv = 0
                for a in args[3:]:
                    if a.startswith("init="):
                        init = int(a[5:])
                    elif a == "invert":
                        inv = 1
                    else:
                        raise AsmError(f"line {ln}: unknown .pin option '{a}'")
                p.pins[name] = (idx, PIN_MODES[mode], inv, init)
            elif d == ".in":
                p.in_pin = args[0]
            elif d == ".start":
                p.start = args[0]
            else:
                raise AsmError(f"line {ln}: unknown directive {d}")
            continue
        m = re.fullmatch(r"state\s+(\w+)\s*:", line)
        if m:
            cur = (m.group(1), [], ln)
            p.states.append(cur)
            continue
        if line.startswith("when"):
            if cur is None:
                raise AsmError(f"line {ln}: rule outside a state")
            cur[1].append((line, ln))
            continue
        raise AsmError(f"line {ln}: cannot parse '{line}'")
    return p


def parse_guard(tok, p, ln):
    tok = tok.strip()
    neg = 0
    if tok.startswith("!"):
        neg, tok = 1, tok[1:].strip()
    up = tok.upper()
    if up == "NEVER":
        return (0, 1 - neg)
    if up in GUARD_SRC:
        return (GUARD_SRC[up], neg)
    m = re.fullmatch(r"(rise|fall)\((\w+)\)", tok)
    if m:
        base = PIN_RISE if m.group(1) == "rise" else PIN_FALL
        return (base + p.pin_index(m.group(2), ln), neg)
    return (PIN_LVL + p.pin_index(tok, ln), neg)     # bare pin name = level


def assemble(text, defines=None):
    p = parse(text, defines)
    if not p.states:
        raise AsmError("no states")
    if len(p.states) > NUM_BLOCKS:
        raise AsmError(f"{len(p.states)} states, but v0 has only {NUM_BLOCKS} blocks")
    index = {name: i for i, (name, _, _) in enumerate(p.states)}
    if len(index) != len(p.states):
        raise AsmError("duplicate state name")
    start = p.start or p.states[0][0]
    if start not in index:
        raise AsmError(f".start names unknown state {start}")

    rule_rx = re.compile(r"when\s+(.+?)\s*(?:do\s+(.+?))?\s*->\s*(\w+)\s*$")
    words = []
    for si, (sname, rules, sln) in enumerate(p.states):
        if len(rules) > RULES_PER_BLOCK:
            raise AsmError(f"line {sln}: state {sname} has {len(rules)} rules, max {RULES_PER_BLOCK}")
        for slot in range(RULES_PER_BLOCK):
            addr = si * RULES_PER_BLOCK + slot
            if slot >= len(rules):
                words.append((addr, NEVER))
                p.listing.append(f"{addr:02X}  {NEVER:08X}  {sname:<8} (empty)")
                continue
            text_, ln = rules[slot]
            m = rule_rx.fullmatch(text_)
            if not m:
                raise AsmError(f"line {ln}: expected 'when GUARD [& GUARD] [do ACTIONS] -> STATE'")
            gtxt, atxt, nxt = m.groups()
            if nxt not in index:
                raise AsmError(f"line {ln}: unknown next state {nxt}")
            gl = [g for g in gtxt.split("&")]
            if len(gl) > 2:
                raise AsmError(f"line {ln}: at most two guards per rule")
            ga = parse_guard(gl[0], p, ln)
            gb = parse_guard(gl[1], p, ln) if len(gl) == 2 else (0, 0)
            f = dict(pin_op=0, pin_sel=0, sh_op=0, tm_op=0, cn_op=0, fx_op=0)
            used = set()

            def setf(group, **kv):
                if group in used:
                    raise AsmError(f"line {ln}: two {group} actions in one rule")
                used.add(group)
                f.update(kv)

            for a in [x.strip() for x in (atxt or "").split(",") if x.strip()]:
                al = a.lower()
                if "=" in a and a.split("=")[0].strip() in p.pins:
                    pn, val = [x.strip() for x in a.split("=")]
                    op = {"0": 1, "1": 2, "bit": 3}.get(val.lower())
                    if op is None:
                        raise AsmError(f"line {ln}: pin value must be 0, 1 or bit")
                    setf("pin", pin_op=op, pin_sel=p.pins[pn][0])
                elif al == "shift_in":
                    setf("shift", sh_op=1)
                elif al == "shift_out":
                    setf("shift", sh_op=2)
                elif al == "load_tx":
                    setf("shift", sh_op=3)
                elif al in ("timer=a", "timer=b"):
                    setf("timer", tm_op=1 if al.endswith("a") else 2)
                elif al in ("count=load", "count=dec"):
                    setf("count", cn_op=1 if al.endswith("load") else 2)
                elif al == "push_rx":
                    setf("fifo", fx_op=1)
                elif al == "set_flag":
                    setf("fifo", fx_op=2)
                elif al == "clr_flag":
                    setf("fifo", fx_op=3)
                else:
                    raise AsmError(f"line {ln}: unknown action '{a}'")
            if f["tm_op"] and p.timer["AB"[f["tm_op"] - 1]] is None:
                raise AsmError(f"line {ln}: timer={'AB'[f['tm_op'] - 1]} used but not set")
            w = encode_rule(ga, gb, nxt=index[nxt], **f)
            words.append((addr, w))
            p.listing.append(f"{addr:02X}  {w:08X}  {sname:<8} {text_[4:].strip()}")

    # loader write sequence: stop, rules, config, then run
    if p.in_pin is not None:
        in_sel = p.pin_index(p.in_pin, 0)
    else:
        in_sel = 0
    pin_cfg = 0
    for name, (idx, mode, inv, init) in p.pins.items():
        pin_cfg |= (mode | (inv << 2) | (init << 3)) << (4 * idx)
    seq = [(REG["CTRL"], 0)]
    seq += words
    seq.append((REG["TIMER_A"], (p.timer["A"] or 1) - 1))
    seq.append((REG["TIMER_B"], (p.timer["B"] or 1) - 1))
    seq.append((REG["LANE_CFG"], p.cnt_init | (p.msb_first << 6) | (in_sel << 8)))
    seq.append((REG["PIN_CFG"], pin_cfg))
    seq.append((REG["CTRL"], 1 | (index[start] << 4)))
    p.writes = seq
    return p


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("source")
    ap.add_argument("-D", action="append", default=[], metavar="NAME=VALUE")
    ap.add_argument("-o", "--output")
    ap.add_argument("--list", action="store_true", help="print a listing")
    a = ap.parse_args(argv)
    defines = {}
    for d in a.D:
        k, v = d.split("=", 1)
        defines[k] = _eval(v, {})
    try:
        prog = assemble(open(a.source).read(), defines)
    except AsmError as e:
        sys.exit(f"{a.source}: error: {e}")
    out = "\n".join(f"{ad:02X} {w:08X}" for ad, w in prog.writes) + "\n"
    if a.output:
        open(a.output, "w").write(out)
    if a.list or not a.output:
        print("addr  word      state    rule")
        print("\n".join(prog.listing))
        print(f"timer_a={prog.timer['A']} cycles, timer_b={prog.timer['B']} cycles, "
              f"counter={prog.cnt_init}, {'msb' if prog.msb_first else 'lsb'} first")
        if not a.output:
            print("\nloader writes:\n" + out, end="")


if __name__ == "__main__":
    main()
